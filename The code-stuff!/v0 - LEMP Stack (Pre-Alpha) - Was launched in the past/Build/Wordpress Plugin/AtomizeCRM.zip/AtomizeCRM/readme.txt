=== AtomizeCRM Chat ===
Contributors: Team AtomizeCRM
Donate link:
Tags: customer service, live chat, support, faqs, bug reporting, ai
Requires at least: 4.0
Tested up to: 4.8
Stable tag: trunk
Requires PHP: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin enables a one-click install to the AtomizeCRM chat support widget.

== Description ==

This plugin enables a one-click install to the AtomizeCRM chat support widget.

This plugin requires an AtomizeCRM account.

== Installation ==

1. Install this plugin.
2. Activate the plugin.
3. Sign into your AtomizeCRM account and head to the "Authorised Websites" page.
4. Add the URL of your website to the list.
5. Done!

== Frequently Asked Questions ==

= How do I get an AtomizeCRM account? =

Head to our website, https://atomizecrm.com

= How do I activate my plugin? =

Sign into your AtomizeCRM account and head to the "Authorised Websites" page.


== Screenshots ==

1. AtomizeCRM Support Widget

== Changelog ==


== Upgrade Notice ==
